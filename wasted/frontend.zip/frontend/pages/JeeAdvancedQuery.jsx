import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Sparkles, TrendingUp, Award, MapPin, Calendar, BookOpen, Users, Star, ExternalLink } from 'lucide-react';

const JeeAdvancedQuery = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      content: "Hello! I'm your JEE Advanced admission assistant. I can help you find the best IITs and NITs based on your rank, category, and preferences. What's your JEE Advanced rank?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const [selectedCategory, setSelectedCategory] = useState('General');
  const [quickQueries] = useState([
    "What IITs can I get with rank 2000?",
    "Best branches in IIT Delhi for my rank",
    "Compare IIT Bombay vs IIT Madras",
    "Closing ranks for Computer Science",
    "IIT admission process timeline"
  ]);

  const categories = ['General', 'OBC', 'SC', 'ST', 'EWS', 'PwD'];

  const mockColleges = [
    {
      name: "IIT Bombay",
      branch: "Computer Science Engineering",
      closingRank: 1800,
      fees: "₹2.5L/year",
      rating: 4.8,
      location: "Mumbai, Maharashtra",
      highlights: ["Top placement records", "Research opportunities", "Industry connections"]
    },
    {
      name: "IIT Delhi",
      branch: "Electrical Engineering",
      closingRank: 2200,
      fees: "₹2.5L/year",
      rating: 4.7,
      location: "New Delhi",
      highlights: ["Central location", "Strong alumni network", "Innovation hub"]
    },
    {
      name: "IIT Madras",
      branch: "Mechanical Engineering",
      closingRank: 2500,
      fees: "₹2.5L/year",
      rating: 4.6,
      location: "Chennai, Tamil Nadu",
      highlights: ["Research excellence", "Industry partnerships", "Cultural diversity"]
    }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateBotResponse = (userMessage) => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('rank') && /\d+/.test(message)) {
      const rank = message.match(/\d+/)[0];
      return {
        type: 'colleges',
        content: `Based on your JEE Advanced rank ${rank} in ${selectedCategory} category, here are your top college options:`,
        colleges: mockColleges.filter(college => parseInt(rank) <= college.closingRank + 500)
      };
    }
    
    if (message.includes('iit') || message.includes('college')) {
      return {
        type: 'text',
        content: "IITs are premier engineering institutions in India. With JEE Advanced, you can get admission to 23 IITs across the country. Each IIT has its unique strengths and specializations. Would you like me to suggest colleges based on your rank?"
      };
    }
    
    if (message.includes('branch') || message.includes('course')) {
      return {
        type: 'text',
        content: "Popular branches in IITs include Computer Science, Electrical, Mechanical, Chemical, and Civil Engineering. The choice depends on your interests and career goals. Computer Science typically has the highest cutoffs. What's your preferred branch?"
      };
    }
    
    return {
      type: 'text',
      content: "I can help you with JEE Advanced college predictions, branch selection, and admission guidance. Please share your rank or ask specific questions about IITs and NITs!"
    };
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: messages.length + 1,
      type: 'user',
      content: inputMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    setTimeout(() => {
      const botResponse = generateBotResponse(inputMessage);
      const botMessage = {
        id: messages.length + 2,
        type: 'bot',
        content: botResponse.content,
        colleges: botResponse.colleges,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleQuickQuery = (query) => {
    setInputMessage(query);
  };

  const CollegeCard = ({ college }) => (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-xl p-4 shadow-lg border border-purple-100 hover:shadow-xl transition-all duration-300"
    >
      <div className="flex justify-between items-start mb-3">
        <div>
          <h4 className="font-bold text-gray-800 text-lg">{college.name}</h4>
          <p className="text-purple-600 font-medium">{college.branch}</p>
        </div>
        <div className="flex items-center space-x-1 bg-yellow-50 px-2 py-1 rounded-lg">
          <Star className="w-4 h-4 text-yellow-500 fill-current" />
          <span className="text-sm font-medium text-yellow-700">{college.rating}</span>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-3 mb-3 text-sm">
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-4 h-4 text-green-500" />
          <span className="text-gray-600">Rank: {college.closingRank}</span>
        </div>
        <div className="flex items-center space-x-2">
          <Award className="w-4 h-4 text-blue-500" />
          <span className="text-gray-600">{college.fees}</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-2 mb-3">
        <MapPin className="w-4 h-4 text-red-500" />
        <span className="text-gray-600 text-sm">{college.location}</span>
      </div>
      
      <div className="space-y-1 mb-3">
        {college.highlights.map((highlight, index) => (
          <div key={index} className="flex items-center space-x-2">
            <div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div>
            <span className="text-xs text-gray-600">{highlight}</span>
          </div>
        ))}
      </div>
      
      <button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-2 rounded-lg font-medium hover:from-purple-600 hover:to-pink-600 transition-all duration-200 flex items-center justify-center space-x-2">
        <span>View Details</span>
        <ExternalLink className="w-4 h-4" />
      </button>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-purple-100">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="flex items-center justify-center space-x-3 mb-2">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                JEE Advanced Query
              </h1>
            </div>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Get personalized IIT and NIT recommendations based on your JEE Advanced rank
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Category Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="bg-white rounded-xl p-4 shadow-sm border border-purple-100">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Select Your Category</h3>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                    selectedCategory === category
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Quick Queries */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <div className="bg-white rounded-xl p-4 shadow-sm border border-purple-100">
            <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-purple-500" />
              <span>Quick Queries</span>
            </h3>
            <div className="flex flex-wrap gap-2">
              {quickQueries.map((query, index) => (
                <motion.button
                  key={index}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleQuickQuery(query)}
                  className="px-3 py-2 bg-purple-50 text-purple-700 rounded-lg text-sm hover:bg-purple-100 transition-colors duration-200 border border-purple-200"
                >
                  {query}
                </motion.button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Chat Container */}
        <div className="bg-white rounded-xl shadow-lg border border-purple-100 overflow-hidden">
          {/* Messages */}
          <div className="h-96 overflow-y-auto p-4 space-y-4">
            <AnimatePresence>
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-xs lg:max-w-md xl:max-w-lg ${
                    message.type === 'user' 
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-l-2xl rounded-tr-2xl' 
                      : 'bg-gray-100 text-gray-800 rounded-r-2xl rounded-tl-2xl'
                  } p-4 shadow-sm`}>
                    <div className="flex items-start space-x-2 mb-2">
                      {message.type === 'bot' ? (
                        <Bot className="w-5 h-5 text-purple-500 mt-0.5" />
                      ) : (
                        <User className="w-5 h-5 text-white mt-0.5" />
                      )}
                      <div className="flex-1">
                        <p className="text-sm leading-relaxed">{message.content}</p>
                        {message.colleges && (
                          <div className="mt-4 space-y-3">
                            {message.colleges.map((college, index) => (
                              <CollegeCard key={index} college={college} />
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                    <p className={`text-xs opacity-70 text-right ${
                      message.type === 'user' ? 'text-white' : 'text-gray-500'
                    }`}>
                      {message.timestamp}
                    </p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            
            {isTyping && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start"
              >
                <div className="bg-gray-100 rounded-r-2xl rounded-tl-2xl p-4 shadow-sm">
                  <div className="flex items-center space-x-2">
                    <Bot className="w-5 h-5 text-purple-500" />
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t border-gray-200 p-4">
            <div className="flex space-x-3">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ask about IITs, NITs, or share your JEE Advanced rank..."
                className="flex-1 border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleSendMessage}
                disabled={!inputMessage.trim()}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-medium hover:from-purple-600 hover:to-pink-600 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                <Send className="w-5 h-5" />
                <span className="hidden sm:inline">Send</span>
              </motion.button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JeeAdvancedQuery;